p = open('p067_triangle.txt','r').read()
pyr = []
for l in p.splitlines():
	x = [[int(a),0] for a in l.split(' ')]
	pyr.append(x)

pyr[0][0][1] = pyr[0][0][0]
for s in range(1,len(pyr)):
	stage = pyr[s]
	for i in range(len(stage)):
		b = stage[i]
		if(i == 0):
			b[1] = pyr[s-1][0][1] + b[0]
		elif(i == len(stage)-1):
			b[1] = pyr[s-1][i-1][1] + b[0]
		else:
			b[1] = max(pyr[s-1][i-1][1],pyr[s-1][i][1]) + b[0]

print(max(pyr[-1],key=lambda x: x[1]))


