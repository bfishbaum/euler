#Solved
def sq_dist(a,b):
	return (a[0]-b[0])**2 + (a[1]-b[1])**2

def isRT(a,b):
	if(a == b): return False
	if(a[0] == b[0] and b[1] < a[1]): return False
	if(a == (0,0) or b == (0,0)): return False
	if(a[1] == 0 and b[1] == 0): return False
	if(a[0] == 0 and b[0] == 0): return False
	A = (a[0]**2 + a[1]**2)
	B = (b[0]**2 + b[1]**2)
	C = sq_dist(a,b)
	return (A+B+C)/2 in [A,B,C]


k = 51
t = 0
for x1 in range(k):
	print(t)
	for y1 in range(k):
		for x2 in range(x1,k):
			for y2 in range(k):
				if(isRT((x1,y1),(x2,y2))):
					t += 1
print(t)

