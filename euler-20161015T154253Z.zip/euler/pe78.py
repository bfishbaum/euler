#Solved
d = {0:1,1:1}

def pent(n):
	return (3*n**2-n)//2

def genPent(n):
	n += 1
	return n//2 * (-1 if n%2==1 else 1)

pN = [pent(genPent(n)) for n in range(10000)]
print(pN[:5])
#def part(n,i=1):
	#stack = [(n,i,0,False)]
	#total = 0 
	#global d
	#while(stack != []):
		#(n,i,t,f) = stack[-1]
		#if((n,i) in d):
			#stack.pop()
			#total += d[(n,i)]
		#elif(f):
			#stack.pop()
			#d[(n,i)] = total - t	
		#else:
			#stack[-1] = (n,i,total,True)
			#if(n == 0):
				#d[(n,i)] = 1 
				#total += 1
			#elif(n < 0 or n < i):
				#d[(n,i)] = 0 
			#elif(n < 2*i):
				#d[(n,i)] = 1 
				#total += 1
			#else:
				#s = 0
				#for x in range(0,n+1,i):
					#stack.append((n-x,i+1,0,False))
	#return total

def part(k):
	if(k < 0): return 0
	elif(k == 0): return 1
	else:
		s = 0
		c = 1
		j = 2
		while(pN[c] <= k):
			s += d.get(k-pN[c],0) * (-1 if j == 0 or j == 1 else 1)
			c += 1
			j += 1
			j = j % 4

		d[k] = s
		return s
	
k = 1
while(True):
	x = part(k)
	if(k % 1000 == 0):
		print(k)
	if(x % 1000000 == 0):
		print(k,x)
		break
	k += 1

